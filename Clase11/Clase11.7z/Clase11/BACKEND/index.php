<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/AutentificadorJWT.php';

require_once './clases/Usuarios.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

////USAR APRA AUTENTICACION ULTIMA LINEA           })->add($mdwAuth);

$app = new \Slim\App(["settings" => $config]);

$app->group('/usuarios', function () 
{    
    //LOGIN
    $this->post('/Login',\Usuarios::class . '::Login')->add(\Usuarios::class . '::MdwLogin')->add(\Usuarios::class . '::MdwLoginVacio'); //->add(\Usuarios::class . ':MdwLoginVacio')->add(\Usuarios::class . ':MdwLogin')
    
    //AGREGAR EMPLEADO  *************************/
    $this->post('/Alta',\Usuarios::class . '::Alta');
    
    //TRAER TODOS LOS EMPLEADOS *************************/
    $this->post('/TraerTodos',\Usuarios::class . '::TraerTodos'); //$this->post('/TraerTodos',\Usuarios::class . ':TraerTodos')->add($mdwAuth); para verificar token
    
    //TRAER EMPLEADO POR LEGAJO *************************/
    $this->post('/TraerPorLegajo',\Usuarios::class . '::TraerPorLegajo'); //$this->post('/TraerPorLegajo',\Usuarios::class . ':TraerPorLegajo')->add($mdwAuth);
    
    //MODIFICAR EMPLEADO *************************/
    $this->post('/Modificar',\Usuarios::class . '::Modificar'); //$this->post('/Modificar',\Usuarios::class . ':Modificar')->add($mdwAuth);
    
    //BORRAR EMPLEADO *************************/
    $this->post('/Borrar',\Usuarios::class . '::Borrar'); //$this->post('/Borrar',\Usuarios::class . ':Borrar')->add($mdwAuth);
});
    

$app->run();
