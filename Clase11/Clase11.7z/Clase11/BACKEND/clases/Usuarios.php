<?php

require_once 'IApiUsuarios.php';
require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class Usuarios implements IApiUsuarios
{
    private $username;
    private $password;
    private $repassword;


    //VERIFICAR LOGIN QUE NO HAYA ""
    public static function MdwLoginVacio($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        if(isset($datos['username']) && isset($datos['password']))
        {
            if($datos['username'] != "" && $datos['password'] != "")
            {
                $newResponse =$next($request, $response);
            } 
            else
            {
                $newResponse = $response->withJson("Error",401);
            }
        }   

        return $newResponse;
    }


    //VERIFICAR LOGIN QUE COINCIDA USUARIO Y CONTRASEÑA
    public static function MdwLogin($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $username = $datos['username'];

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE user=:username");

        $consulta->bindValue(':username',$username);
        $consulta->execute();
        $datosConsulta = $consulta->fetchAll(PDO::FETCH_ASSOC);

        if(password_verify($datos['password'], $datosConsulta[0]['pass']))
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson("Error",401);
        }

        return $newResponse;
    }



   //VERIFICAR USER
   public static function verificarUsuario($username)
   {
        $retorno = false;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE user=:username");
        $consulta->bindValue(":username",$username);
        $consulta->execute();
        $datos = $consulta->fetchAll(PDO::FETCH_ASSOC);

        if(!isset($datos[0]) && $username!="")
        {
            $retorno = true;
        }

        return $retorno;
   }

    //TRAER usuario POR ID
    public static function traerUsuarioPorId($id)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE id_usuario=:id");
        $consulta->bindValue(":id",$id);
        $consulta->execute();
        $datos = $consulta->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($datos);     
    }

    //Login
    public static function Login($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $jwt = AutentificadorJWT::CrearToken($datos);

        $newResponse = $response->withJson($jwt,200);

        return $newResponse;
       
    }

    //AGREGAR Usuario
    public static function Alta($request, $response, $args)
    { 
        $datos = $request->getParsedBody();

        /*$jsonDatos = $datos['jsonDatos'];
        $empleado = json_decode($jsonDatos);
        
        $fotos = $request->getUploadedFiles();
        $nombreFoto = $fotos["foto"]->getClientFileName();
        $ubicacionFoto = "./fotos/".date("dis")."_".$empleado->legajo.".".pathinfo($nombreFoto, PATHINFO_EXTENSION);
        $fotos["foto"]->moveTo($ubicacionFoto);
        
        $legajo = $empleado->legajo;
        $nombre = $empleado->nombre;
        $mail = $empleado->mail;
        $clave = password_hash($empleado->clave, PASSWORD_BCRYPT);
        $sexo = $empleado->sexo;
        $apellido = $empleado->apellido;
        $foto = $ubicacionFoto;
        $sueldo = $empleado->sueldo;
        $dni = $empleado->dni;*/

        $json = new stdClass();  
        
            $username = $datos['regusername'];
            $password = password_hash($datos['regpassword'], PASSWORD_BCRYPT);

            if(Usuarios::verificarUsuario($username))
            {

                $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into  
                usuarios (user, pass)
                values(:user, :pass)");

                $consulta->bindValue(':user',$username);
                $consulta->bindValue(':pass', $password);

                $consulta->execute();

                $json->exito=true; 
                $json->mensaje="OK"; 

                $newResponse = $response->withJson($json, 200);
            }
            else
            {
                $json->exito=false; 
                $json->mensaje="Nombre de usuario en uso."; 

                $newResponse = $response->withJson($json, 401);
            }      

        return $newResponse;
    }
   

    //TRAER TODOS LOS empleados
    public static function TraerTodos($request, $response, $args)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * 
        FROM usuarios");
        
        $consulta->execute();
        $consulta = $consulta->fetchAll(PDO::FETCH_ASSOC);

        return json_encode($consulta);
    }

    //TRAER empleado POR LEGAJO
    public static function TraerPorLegajo($request, $response, $args)
    {
        $datos = $request->getParsedBody();
        $legajo = $datos['legajo'];

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * 
        FROM usuarios WHERE legajo=$legajo");

        $consulta->bindValue(":legajo",$legajo);
        $consulta->execute();
        $datos = $consulta->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($datos);     
    }

   //MODIFICAR empleado
    public static function Modificar($request, $response, $args)
    {
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $empleado = json_decode($jsonDatos);

        $fotos = $request->getUploadedFiles();
        $nombreFoto = $fotos["foto"]->getClientFileName();
        $ubicacionFoto = "./fotos/".date("dis")."_".$empleado->legajo.".".pathinfo($nombreFoto, PATHINFO_EXTENSION);
        $fotos["foto"]->moveTo($ubicacionFoto);

        /*//$empleadoViejo lo traigo creando una funcion que solamente traiga un usuario de la base de datos

        copy("./fotos/".$empleadoViejo->foto, "./fotos/modificadas/".$empleadoViejo->foto);
        unlink("./fotos/".$empleadoViejo->foto);*/
        
        $legajo = $empleado->legajo;
        $nombre = $empleado->nombre;
        $mail = $empleado->mail;
        $clave = password_hash($empleado->clave, PASSWORD_BCRYPT);
        $sexo = $empleado->sexo;
        $apellido = $empleado->apellido;
        $foto = $ubicacionFoto;
        $sueldo = $empleado->sueldo;
        $dni = $empleado->dni;

        $json = new stdClass();
        $json->exito=false; 
        $json->mensaje="No se pudo modificar."; 
        $newResponse = $response->withJson($json, 401);

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta
        ('UPDATE usuarios SET nombre = :nombre, mail = :mail, clave = :clave, sexo = :sexo, apellido = :apellido, sueldo = :sueldo, foto = :foto, dni = :dni WHERE legajo = :legajo' );

        $consulta->bindValue(':nombre', $nombre);
        $consulta->bindValue(':mail',$mail);
        $consulta->bindValue(':clave', $clave);
        $consulta->bindValue(':sexo', $sexo);
        $consulta->bindValue(':apellido',$apellido);
        $consulta->bindValue(':foto',$foto);
        $consulta->bindValue(':sueldo',$sueldo);
        $consulta->bindValue(':dni',$dni);
        $consulta->bindValue(':legajo', $legajo);

        if ($consulta->execute()){
            $json->exito=true; 
            $json->mensaje="Se pudo modificar."; 
            $newResponse = $response->withJson($json, 200);
        }

        return $newResponse;
    }

    //BORRAR empleado
    public static function Borrar($request, $response, $args)
    {
        $jsonDatos = $datos['jsonDatos'];
        $empleado = json_decode($jsonDatos);

        $legajo = $empleado->legajo;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("DELETE FROM usuarios WHERE legajo=$legajo");
        $consulta->bindValue(":legajo",$legajo);

        //La foto borrada quedara en fotos/Eliminadas/

        return $consulta->execute();      
    }

 
}
?>