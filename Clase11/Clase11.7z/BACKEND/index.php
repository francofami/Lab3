<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/AutentificadorJWT.php';

require_once './clases/Usuarios.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

////USAR APRA AUTENTICACION ULTIMA LINEA           })->add($mdwAuth);

$app = new \Slim\App(["settings" => $config]);

$app->group('/usuarios', function () 
{

    $this->get('[/]', function (Request $request, Response $response) {    
        $response->getBody()->write("GET => Bienvenido!!! ,a SlimFramework");
        return $response;
    
    });
    
    //************ LOGIN ************//
    $this->post('/login', function (Request $request, Response $response) {
        $datos = $request->getParsedBody();
        $mail = $datos["mail"];
        $password = $datos["password"];
        $newResponse = $response->withJson(Usuarios::login($mail,$password));
        //$response->write($pw);
        return $newResponse;
    });
    
    //************ AUTENTICACION ************//
    $mdwAuth = function ( $request, $response, $next) {
        $token = $request->getHeader('token');
        if(AutentificadorJWT::verificarToken($token[0])){
            $response = $next($request,$response);
        }  
        return $response;
    };

    //************ AUTENTICACION ************//
    $mdwLog = function ( $request, $response, $next) {
        $response->getBody()->write("GET => Bienvenido!!! ,a SlimFramework");
        echo $response;
    };
    
    ////revisar!
    $this->post('/leerHeader', function (Request $request, Response $response) {
        $datos = $request->getParsedBody();
        $header = $request->getHeader('miHeader');
        $leido = AutentificadorJWT::ObtenerPayLoad($header);
        var_dump($leido);
        $newResponse = $response->withJson($header, 200); 
        return $newResponse;
    });
    //************************//
    
    //************ EMPLEADOS ************//

    //LOGIN
    $this->post('/Login',\Usuarios::class . ':Login')->add(\Usuarios::class . '::MdwLoginVacio'); //->add(\Usuarios::class . ':MdwLoginVacio')->add(\Usuarios::class . ':MdwLogin')
    
    //AGREGAR EMPLEADO  *************************/
    $this->post('/Alta',\Usuarios::class . ':Alta');
    
    //TRAER TODOS LOS EMPLEADOS *************************/
    $this->post('/TraerTodos',\Usuarios::class . ':TraerTodos'); //$this->post('/TraerTodos',\Usuarios::class . ':TraerTodos')->add($mdwAuth); para verificar token
    
    //TRAER EMPLEADO POR LEGAJO *************************/
    $this->post('/TraerPorLegajo',\Usuarios::class . ':TraerPorLegajo'); //$this->post('/TraerPorLegajo',\Usuarios::class . ':TraerPorLegajo')->add($mdwAuth);
    
    //MODIFICAR EMPLEADO *************************/
    $this->post('/Modificar',\Usuarios::class . ':Modificar'); //$this->post('/Modificar',\Usuarios::class . ':Modificar')->add($mdwAuth);
    
    //BORRAR EMPLEADO *************************/
    $this->post('/Borrar',\Usuarios::class . ':Borrar'); //$this->post('/Borrar',\Usuarios::class . ':Borrar')->add($mdwAuth);
});
    

$app->run();
