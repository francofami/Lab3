<?php

interface IApiUsuarios
{
    public static function Alta($request, $response, $args);
    public static function TraerTodos($request, $response, $args);
    public static function TraerPorLegajo($request, $response, $args);
    public static function Modificar($request, $response, $args);
    public static function Borrar($request, $response, $args);
    public static function Login($request, $response, $args);
}

?>