/// <reference path="./node_modules/@types/jquery/index.d.ts" />

$(document).ready(function()
{
    loginForm();

    mostrarRegistroEnModal();
});

function Login()
{
    let xhr : XMLHttpRequest = new XMLHttpRequest();
     
    var email : string = (<HTMLInputElement> document.getElementById("email")).value;
    var password : string = (<HTMLInputElement> document.getElementById("password")).value;

    var obj: Object = {
        correo: email,
        clave: password,
    };

    var json = JSON.stringify(obj);

    let form : FormData = new FormData();
    form.append('jsonDatos', json);
    xhr.open('POST', './BACKEND/index.php/login/', true);
    xhr.setRequestHeader("enctype", "multipart/form-data");
    xhr.send(form);  
    
    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            var respuesta : string = xhr.responseText;

            var objRespuesta : any = JSON.parse(respuesta);

            var token = objRespuesta.jwt;

            if(objRespuesta.exito == true)
            {
                localStorage.setItem("token", token);
                window.location.replace("./principal.html");
            }
        }
        else if(xhr.readyState == 4 && xhr.status != 200)
        {
            $('#errorLogin').removeClass("hide");
        }
    }
}

function loginForm()
{
        $("#loginForm").bootstrapValidator({
            message: "Error",
            feedbackIcons:{
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },

            fields:{
                email:{
                    validators:{
                        regexp: {
                            regexp: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
                            message: 'Ingrese un email valido.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                },
                password:{
                    validators:{
                        stringLength: {
                            min: 4,
                            max: 8,
                            message: 'La contraseña debe contener entre 4 y 8 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                }
            }
        })
}

function mostrarRegistroEnModal()
{
    //Hace que al hacer click al boton registro se vea el documento html registro en el modal del html login
    $('.btn-success').on('click',function(){
        $('.modal-body').load('./registro.html', function(){
            $('#myModal').modal({show:true});
        });
    });
}