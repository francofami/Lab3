/// <reference path="./node_modules/@types/jquery/index.d.ts" />

$(document).ready(function()
{
    registerForm();
});

function Registro() 
{
    var xhr : XMLHttpRequest = new XMLHttpRequest();

    var regcorreo : string = (<HTMLInputElement> document.getElementById("regcorreo")).value;
    var regpassword : string = (<HTMLInputElement> document.getElementById("regpassword")).value;
    var regnombre : string = (<HTMLInputElement> document.getElementById("regnombre")).value;
    var regapellido : string = (<HTMLInputElement> document.getElementById("regapellido")).value;
    var regperfil : string = (<HTMLInputElement> document.getElementById("regperfil")).value;
    var fotoInput :any = <HTMLInputElement> document.getElementById("regfoto");


    //var path = document.getElementById("regfoto").value;
    //var pathFoto = (path.split('\\'))[2];
    var form = new FormData();
    
    //var json = "{'correo':'" + regcorreo + "','clave':'" + regpassword + "','nombre':'" + regnombre + "','apellido':'" + regapellido + "','perfil':'" + regperfil + "'}";
    
    var obj: Object = {
        correo: regcorreo,
        clave: regpassword,
        nombre: regnombre,
        apellido: regapellido,
        perfil: regperfil,
    };

    var json = JSON.stringify(obj);

    form.append('jsonDatos', json);
    form.append('regfoto', fotoInput.files[0]);
    xhr.open('POST', './BACKEND/index.php/usuarios/Alta', true);
    xhr.setRequestHeader("enctype", "multipart/form-data");
    xhr.send(form);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);

            var respuesta = JSON.parse(xhr.responseText);

            if(respuesta.exito == true)
            {
                //$('#myModal').modal({show:false});

                $('#myModal').hide();
                $('.modal-backdrop').hide();

                //window.location.replace("./login.html");


                $('#OKReg').removeClass("hide");
            }

            //(<HTMLInputElement> document.getElementById("errorReg")).type = "";
            //(<HTMLInputElement> document.getElementById("errorReg")).style.display = "block";
            //$('#errorReg').removeClass("hide");
            //$('#errorReg').addClass("alert alert-danger show");
            //$('#errorReg').alert();
            //Segun la respuesta , registro correcto o no poner una ventana que avise lo acontecido    
            //$('#myModal').modal("hide");
            //window.location.replace("./login.php");
        }
        else if (xhr.readyState == 4 && xhr.status != 200) {
            console.log(xhr.responseText);
            $('#errorReg').removeClass("hide");
        }
    };
}

function registerForm()
{
    $("#registerForm").bootstrapValidator({
            message: "Error",
            feedbackIcons:{
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },

            fields:{
                regcorreo:{
                    validators:{
                        regexp: {
                            regexp: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
                            message: 'Ingrese un email valido.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                },
                password:{
                    validators:{
                        stringLength: {
                            min: 4,
                            max: 8,
                            message: 'La contraseña debe contener entre  y 8 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                        identical: {
                            field: 'password',
                            message: 'La contraseña y su confirmación no coinciden!'
                        },
                    }
                },
                regnombre:{
                    validators:{
                        stringLength: {
                            max: 10,
                            message: 'El nombre debe contener como maximo 10 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        }, 
                    }
                    
                },
                regapellido:{
                    validators:{
                        stringLength: {
                            max: 10,
                            message: 'El apellido debe contener como maximo 15 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        }, 
                    }
                    
                },
                regfoto:{
                    validators:{
                        file: {
                            extension: 'png,jpg',
                            type: 'image/jpeg,image/png,image/jpg',
                            message: 'La foto debe ser jpg o png'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                    
                },
                regperfil:{
                    validators:{
                        notEmpty: {
                            message: 'Seleccione una opcion valida!'
                        },
                    }
                    
                },
            }
        })
}

