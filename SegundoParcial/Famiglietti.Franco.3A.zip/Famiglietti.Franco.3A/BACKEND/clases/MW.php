<?php

require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class MW
{
    public function MdwLoginSeteado($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        //var_dump($datos);

        if(isset($datos['jsonDatos']) && !empty($datos))
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, datos no seteados."], 403);
        }
        
        return $newResponse;
    }

    public static function MdwLoginVacio($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        if(strlen($usuario->correo) == 0 || strlen($usuario->clave) == 0)
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, datos vacios."], 409);
        } 
        else
        {
            $newResponse = $next($request, $response);
        }

        return $next($request, $response);
    }

    public function MdwVerificarBaseDeDatos($request, $response, $next)
    {
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        $usuarioCompleto = Usuarios::traerUsuarioPorEmailClave($usuario);

        if(empty($usuarioCompleto))
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, el mail y clave no se encuentran en nuestra base de datos."], 403);
        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;
    }

    public static function MdwVerificarMailBaseDeDatos($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE correo=:correo");

        $consulta->bindValue(":correo",$usuario->correo);
        $consulta->execute();
        
        if($consulta->fetchAll(PDO::FETCH_ASSOC))
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, el mail ya existe."], 403);
        }
        else
        {
            $newResponse = $next($request, $response);
        }

        return $newResponse;  
    }

    public function VerificarToken($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jwt = $datos['jwt'];

        if(AutentificadorJWT::VerificarToken($jwt))
        {
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, token invalido."], 403);
        }

        return $newResponse;
    }
}