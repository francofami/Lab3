<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/Auto.php';
require_once './clases/Usuarios.php';
require_once './clases/MW.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

////USAR APRA AUTENTICACION ULTIMA LINEA           })->add($mdwAuth);

$app = new \Slim\App(["settings" => $config]);

$app->group('/', function () 
{    
    $this->get('', \Usuarios::class . '::Listado');
    $this->post('Alta', \Auto::class . '::Alta');
});

$app->group('/usuarios', function () 
{    
    $this->post('/Alta',\Usuarios::class . '::Alta')->add(\MW::class . '::MdwVerificarMailBaseDeDatos')->add(\MW::class . ':MdwLoginSeteado'); //->add(\MW::class . '::MdwVerificarMailBaseDeDatos')->add(\MW::class . '::MdwLoginVacio')->add(\MW::class . ':MdwLoginSeteado')
});

$app->group('/autos', function () 
{   
    //$this->post(); 
    $this->get('/Listado', \Auto::class . '::Listado');
});

$app->group('/login', function () 
{    
    $this->post('/', \Usuarios::class . '::CrearJWT')->add(\MW::class . ':MdwVerificarBaseDeDatos')->add(\MW::class . '::MdwLoginVacio')->add(\MW::class . ':MdwLoginSeteado');
    $this->get('/', \Usuarios::class . '::VerificarJWT');
});

$app->run();
