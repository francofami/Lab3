<?php

require_once 'AccesoDatos.php';

class Auto
{
    public static function Alta($request, $response, $args)
    { 
        $datos = $request->getParsedBody();

        $jsonDatos = $datos['jsonDatos'];
        $auto = json_decode($jsonDatos);
        
        $color = $auto->color;
        $marca = $auto->marca;
        $precio = $auto->precio;
        $modelo = $auto->modelo;

        $json = new stdClass();  
        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into  
        autos (color, marca, precio, modelo)
        values(:color, :marca, :precio, :modelo)");

        $consulta->bindValue(':color',$color);
        $consulta->bindValue(':marca', $marca);
        $consulta->bindValue(':precio', $precio);
        $consulta->bindValue(':modelo', $modelo);

        if($consulta->execute())
        {
            $json->exito=true; 
            $json->mensaje="OK"; 

            $newResponse = $response->withJson($json, 200);
        }
        else
        {
            $json->exito=false; 
            $json->mensaje="Error."; 

            $newResponse = $response->withJson($json, 418);
        }      

        return $newResponse;
    }

    public static function Listado($request, $response, $args)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT color, marca, precio, modelo FROM autos");
        
        $consulta->execute();

        $json = new stdClass();  

        if($consulta->setFetchMode(PDO::FETCH_ASSOC))
        {
            //$retorno="<table border='1' style='width:0%;height:0%'><tr><th>Color</th><th>Marca</th><th>Precio</th><th>Modelo</th></tr>";


            $retorno=
            
                    '<table class="table table-bordered table-dark">

            <thead class="thead-dark">
                <tr>
                <th scope="col">Color</th>
                <th scope="col">Marca</th>
                <th scope="col">Precio</th>
                <th scope="col">Modelo</th>
                </tr>
            </thead>
            <tbody>';


            while($auto=$consulta->fetch()){
                $retorno.="<tr><td>".$auto["color"]."</td><td>".$auto["marca"]."</td><td>".$auto["precio"]."</td><td>".$auto["modelo"]."</td></tr>";
            }


            /*while($auto=$consulta->fetch()){
                $retorno.="<tr><td>".$auto["color"]."</td><td>".$auto["marca"]."</td><td>".$auto["precio"]."</td><td>".$auto["modelo"]."</td></tr>";
            }*/


            $retorno.="</tbody></table>";

            $json->exito=true; 
            $json->mensaje="OK";
            $json->tabla = $retorno;
             

            $newResponse = $response->withJson($json, 200);
        }
        else
        {
            $json->exito=false; 
            $json->mensaje="Error.";
            $json->tabla = "";

            $newResponse = $response->withJson($json, 424);
        }

        //echo $json->tabla;

        return $newResponse;
    }

}