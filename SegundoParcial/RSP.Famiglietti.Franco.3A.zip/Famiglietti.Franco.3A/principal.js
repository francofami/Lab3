/// <reference path="./node_modules/@types/jquery/index.d.ts" />
$(document).ready(function () {
    VerificarToken();
});
function VerificarToken() {
    var token = localStorage.getItem('token');
    if (token == null) {
        window.location.replace("./login.html");
    }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './BACKEND/login/');
    xhr.setRequestHeader('jwt', token);
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var respuesta = xhr.responseText;
            var objRespuesta = JSON.parse(respuesta);
            if (objRespuesta.exito == true) {
                MostrarTabla();
                MostrarAutos();

                console.log(objRespuesta.perfil);
            }
            else {
                window.location.replace("./login.html");
            }
        }
        else if(xhr.readyState == 4 && xhr.status!=200)
        {
            window.location.replace("./login.html");
        }
    };
}
function MostrarTabla() {
    var tabla = "";
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './BACKEND/');
    //xhr.setRequestHeader('jwt', token);
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var obj = JSON.parse(xhr.responseText);
            tabla = obj.tabla;
            document.getElementById("divTabla").innerHTML = tabla;
        }
    };
}
function MostrarAutos() {
    var tabla = "";
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './BACKEND/autos/Listado');
    //xhr.setRequestHeader('jwt', token);
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var obj = JSON.parse(xhr.responseText);
            tabla = obj.tabla;
            console.log(tabla);
            document.getElementById("divAutos").innerHTML = tabla;
        }
    };
}