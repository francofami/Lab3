/// <reference path="./node_modules/@types/jquery/index.d.ts" />
$(document).ready(function () {
    mostrarRegistroEnModal();
    loginForm();  
});
function Login() {
    var xhr = new XMLHttpRequest();
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var obj = {
        correo: email,
        clave: password
    };
    var json = JSON.stringify(obj);
    var form = new FormData();
    form.append('jsonDatos', json);
    xhr.open('POST', './BACKEND/index.php/login/', true);
    xhr.setRequestHeader("enctype", "multipart/form-data");
    xhr.send(form);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let respuesta = xhr.responseText;
            let objRespuesta = JSON.parse(respuesta);
            var token = objRespuesta.jwt;
            if (objRespuesta.exito == true) {
                localStorage.setItem("token", token);
                window.location.replace("./principal.html");
            }
        }
        else if (xhr.readyState == 4 && xhr.status != 200) {
            $('#errorLogin').removeClass("hide");

            let respuesta = xhr.responseText;
            let objRespuesta = JSON.parse(respuesta);

            document.getElementById("errorLogin").innerHTML = objRespuesta.Mensaje;
        }
    };
}
function loginForm() {
    $("#loginForm").bootstrapValidator({
        message: "Error",
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'El campo no puede estar vacío!'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
                        message: 'Ingrese un email valido.'
                    },
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'El campo no puede estar vacío!'
                    },
                    stringLength: {
                        min: 4,
                        max: 8,
                        message: 'La contraseña debe contener entre 4 y 8 caracteres.'
                    },
                    
                }
            }
        }
    }).on('success.form.bv', function (e) {

        e.preventDefault();

        Login();
    });
}
function mostrarRegistroEnModal() {
    //Carga la pagina registro.html en el modal
        $(".modal-body").load("./registro.html");
}
