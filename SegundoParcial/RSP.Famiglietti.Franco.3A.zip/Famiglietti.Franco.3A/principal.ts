/// <reference path="./node_modules/@types/jquery/index.d.ts" />

$(document).ready(function()
{
    VerificarToken();
});

function VerificarToken()
{
    let token : any = localStorage.getItem('token');

    if(token == null)
    {
        window.location.replace("./login.html");
    }

    let xhr : XMLHttpRequest = new XMLHttpRequest();

    xhr.open('GET', './BACKEND/login/');
    xhr.setRequestHeader('jwt', token);
    xhr.send();

    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            var respuesta : string = xhr.responseText;

            var objRespuesta : any = JSON.parse(respuesta);

            if(objRespuesta.exito == true)
            {
                MostrarTabla();
                MostrarAutos();
            }
            else
            {
                window.location.replace("./login.html");
            }
        }
        else if(xhr.readyState == 4 && xhr.status!=200)
        {
            window.location.replace("./login.html");
        }
    }
}

function MostrarTabla()
{
    var tabla : string = "";

    let xhr : XMLHttpRequest = new XMLHttpRequest();

    xhr.open('GET', './BACKEND/');
    //xhr.setRequestHeader('jwt', token);
    xhr.send();

    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            var obj : any = JSON.parse(xhr.responseText);

            tabla = obj.tabla; 

            (<HTMLDivElement> document.getElementById("divTabla")).innerHTML = tabla;
        }
    }

    
}

function MostrarAutos()
{
    var tabla : string = "";

    let xhr : XMLHttpRequest = new XMLHttpRequest();

    xhr.open('GET', './BACKEND/autos/Listado');
    //xhr.setRequestHeader('jwt', token);
    xhr.send();

    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            var obj : any = JSON.parse(xhr.responseText);

            tabla = obj.tabla; 

            console.log(tabla);

            (<HTMLDivElement> document.getElementById("divAutos")).innerHTML = tabla;
        }
    }

    
}