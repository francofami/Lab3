///<reference path="./librerias/jquery/jquery.min.js"/>

$(document).ready(function()
{
    $("#login-form").bootstrapValidator(
        {
            message: "Hola",
            feedbackIcons:{
                valid: 'valid', //Nombre de icono
                invalid: 'invalid',//Nombre de icono
            },

            fields:{
                username:{
                    validators:{
                        stringLength: {
                            min: 6,
                            max: 30,
                            message: 'The username must be more than 6 and less than 30 characters long'
                        },
                    }
                }
            }
        }      
    );
});
