/// <reference path="./node_modules/@types/jquery/index.d.ts" />


function Registro()
{
    let xhr : XMLHttpRequest = new XMLHttpRequest();

    let regnombre : string = (<HTMLInputElement> document.getElementById("regnombre")).value;
    let regapellido : string = (<HTMLInputElement> document.getElementById("regapellido")).value;
    let regcorreo : string = (<HTMLInputElement> document.getElementById("regcorreo")).value;
    let regpassword : string = (<HTMLInputElement> document.getElementById("regpassword")).value;
    let regperfil : string = (<HTMLInputElement> document.getElementById("regperfil")).value;
    let fotoInput : any = <HTMLInputElement> document.getElementById("regfoto");
    let path: string = (<HTMLInputElement> document.getElementById("regfoto")).value;
    let pathFoto : string = (path.split('\\'))[2];
    
    let form : FormData = new FormData();

    let json :string = "{'correo':'"+regcorreo+"','clave':'"+regpassword+"','nombre':'"+regnombre+"','apellido':'"+regapellido+"','perfil':'"+regperfil+"'}";

    form.append('jsonDatos', json);
    form.append('regfoto', fotoInput.files[0]);
    xhr.open('POST', './BACKEND/index.php/usuarios/Alta', true);
    xhr.setRequestHeader("enctype", "multipart/form-data");
    xhr.send(form);

    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            console.log(xhr.responseText);
            //(<HTMLInputElement> document.getElementById("errorReg")).type = "";
            //(<HTMLInputElement> document.getElementById("errorReg")).style.display = "block";
            //$('#errorReg').removeClass("hide");
            //$('#errorReg').addClass("alert alert-danger show");

            //$('#errorReg').alert();

            //Segun la respuesta , registro correcto o no poner una ventana que avise lo acontecido    

            //$('#myModal').modal("hide");

            

            //window.location.replace("./login.php");


        }
        else if(xhr.readyState == 4 && xhr.status == 401)
        {
            console.log(xhr.responseText);
            $('#errorReg').removeClass("hide");
        }
    }

    
}