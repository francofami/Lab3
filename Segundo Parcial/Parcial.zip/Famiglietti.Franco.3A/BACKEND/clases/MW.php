<?php

class MW
{
    public function MdwLoginVacio($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $jsonDatos = $datos['jsonDatos'];
        $usuario = json_decode($jsonDatos);

        if(isset($datos['jsonDatos']))
        {
           
            if($usuario->correo != "" && $usuario->clave != "")
            {
                $newResponse =$next($request, $response);
            } 
            else
            {
                $newResponse = $response->withJson("Error, datos vacios",403);
            }
            
            
        }   

        return $newResponse;
    }
}