/// <reference path="./node_modules/@types/jquery/index.d.ts" />


function Login()
{
    let xhr : XMLHttpRequest = new XMLHttpRequest();
    let username : string = (<HTMLInputElement> document.getElementById("username")).value;
    let password : string = (<HTMLInputElement> document.getElementById("password")).value;

    let form : FormData = new FormData();
    form.append('username', username);
    form.append('password', password);
    xhr.open('POST', './BACKEND/index.php/usuarios/Login', true);
    xhr.setRequestHeader("enctype", "multipart/form-data");
    xhr.send(form);  
    
    xhr.onreadystatechange = () => 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {

            localStorage.setItem("token", xhr.responseText);

            alert(localStorage.getItem("token"));

            //if(xhr.responseText == "Logueado con éxito!")
            //window.location.replace("./BACKEND/default.php");

            //Hacer una sesion en el momento del login. Para que si alguien entra a bienvenido.php sin haberse logueado tenga que loguearse (lo se porque no hay ninguna sesión) 
        }
    }
}

function RedirRegistro()
{
    window.location.replace("./registro.html");
}