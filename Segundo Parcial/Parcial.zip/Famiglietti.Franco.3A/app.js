$(document).ready(function()
{
    loginForm();
    registerForm();
});

function loginForm()
{
        $("#loginForm").bootstrapValidator({
            message: "Error",
            feedbackIcons:{
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },

            fields:{
                email:{
                    validators:{
                        regexp: {
                            regexp: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
                            message: 'Ingrese un email valido.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                },
                password:{
                    validators:{
                        stringLength: {
                            min: 4,
                            max: 8,
                            message: 'La contraseña debe contener entre 4 y 8 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                }
            }
        })

    .on('success.form.bv', function (e) {

        alert("Submit...");

    });
}

function registerForm()
{
    $("#registerForm").bootstrapValidator({
            message: "Error",
            feedbackIcons:{
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },

            fields:{
                regcorreo:{
                    validators:{
                        regexp: {
                            regexp: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
                            message: 'Ingrese un email valido.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                },
                password:{
                    validators:{
                        stringLength: {
                            min: 4,
                            max: 8,
                            message: 'La contraseña debe contener entre  y 8 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                        identical: {
                            field: 'password',
                            message: 'La contraseña y su confirmación no coinciden!'
                        },
                    }
                },
                password:{
                    validators:{
                        stringLength: {
                            min: 4,
                            max: 8,
                            message: 'La contraseña debe contener entre 4 y 8 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                        identical: {
                            field: 'password',
                            message: 'La contraseña y su confirmación no coinciden!'
                        },
                    }
                },
                regnombre:{
                    validators:{
                        stringLength: {
                            max: 10,
                            message: 'El nombre debe contener como maximo 10 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        }, 
                    }
                    
                },
                regapellido:{
                    validators:{
                        stringLength: {
                            max: 10,
                            message: 'El apellido debe contener como maximo 15 caracteres.'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        }, 
                    }
                    
                },
                regfoto:{
                    validators:{
                        file: {
                            extension: 'png,jpg',
                            type: 'image/jpeg,image/png,image/jpg',
                            message: 'La foto debe ser jpg o png'
                        },
                        notEmpty: {
                            message: 'El campo no puede estar vacío!'
                        },
                    }
                    
                },
                regperfil:{
                    validators:{
                        notEmpty: {
                            message: 'Seleccione una opcion valida!'
                        },
                    }
                    
                },
            }
        })

        .on('success.form.bv', function (e) {

            alert("Submit...");
    
        });
}